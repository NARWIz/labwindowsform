﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LAAAAABA1._2
{
    public partial class nForm2 : LAAAAABA1._2.Form1
    {
        public nForm2()
        {
            InitializeComponent();
        }
    }
}
